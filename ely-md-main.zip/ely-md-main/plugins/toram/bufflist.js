let handler = async (m, { conn, command }) => { 
	conn.reply(m.chat, `╭─────[ List Code Buff ]─────▻
╰──────────────────────▻
_*ATK*_
*Code : 5010007 Lv8*
*Code : 4147129 Lv6*
⊦──────────────────────▻
_*MTK*_
*Code : Sofya - B - 4649 Lv10*
*Code : 1011133 Lv4*
⊦──────────────────────▻
_*STR*_
*Code : 1110033 Lv10*
*Code : 4016699 Lv10*
*Code : 7070777 Lv10*
*Code : 7031997 Lv10*
*Code : 1011069 Lv10*
*Code : 2020303 Lv10*
*Code : 3010095 Lv10*
*Code : 2180000 Lv10*
*Code : 2010085 Lv10*
*Code : 3010003 Lv9*
*Code : 4010417 Lv9*
*Code : El Scaro - A - 1 Lv9*
*Code : 1011201 Lv8*
*Code : 6070013 Lv5*
⊦──────────────────────▻
_*DEX*_
*Code : 2020222 Lv10*
*Code : 7011001 Lv10*
*Code : 1010058 Lv10*
*Code : 1010106 Lv10*
*Code : 5010092 Lv10*
*Code : 4084545 Lv10*
*Code : 1020001 Lv10*
*Code : 7200002 Lv10*
*Code : 5010031 Lv10*
*Code : 6010003 Lv10*
*Code : 1234567 Lv10*
*Code : 1020001 Lv9*
*Code : 6140110 Lv9*
*Code : 1234567 Lv9*
*Code : 7246969 Lv8*
*Code : 1010106 Lv8*
⊦──────────────────────▻
_*INT*_
*Code : 2020707 Lv10*
*Code : 1032222 Lv10*
*Code : 6061294 Lv10*
*Code : 1010489 Lv10*
*Code : 6010701 Lv10*
*Code : 7010018 Lv10*
*Code : 2020707 Lv9*
*Code : 3012000 Lv9*
*Code : 1010036 Lv8*
*Code : 4269420 Lv8*
*Code : El scaro - Z -1234 Lv8*
⊦──────────────────────▻
_*AGI*_
*Code : 7162029 Lv10*
*Code : 3260777 Lv10*
*Code : 3192311 Lv10*
*Code : 3053131 Lv9*
*Code : 7190001 Lv9*
*Code : 5130123 Lv9*
*Code : 3192311 Lv8*
*Code : 4010228 Lv8*
*Code : 3181227 Lv8*
*Code : 1010050 Lv8*
⊦──────────────────────▻
_*VIT*_
*Code : 2020909 Lv9*
*Code : 5130123 Lv9*
*Code : 1012144 Lv8*
*Code : 1010050 Lv8*
*Code : 1012144 Lv4*
⊦──────────────────────▻
_*CRITICAL RATE*_
*Code : 1100000 Lv10*
*Code : 1010006 Lv10*
*Code : 1010092 Lv10*
*Code : 1010017 Lv10*
*Code : 1010050 Lv10*
*Code : 1011010 Lv10*
*Code : 1012000 Lv10*
*Code : 7162029 Lv10*
*Code : 1069927 Lv10*
*Code : 1012000 Lv10*
*Code : 1010433 Lv10*
*Code : 3020108 Lv10*
*Code : 1200069 Lv10*
*Code : 7010086 Lv10*
*Code : 5010098 Lv10*
*Code : 5112709 Lv10*
*Code : 3010048 Lv10*
*Code : 1011010 Lv10*
*Code : 1037777 Lv10*
*Code : 6040107 Lv9*
*Code : 3061206 Lv9*
*Code : 3246969 Lv9*
*Code : 7190311 Lv9*
*Code : 1010038 Lv8*
⊦──────────────────────▻
_*ACCURACY*_
*Code : 4261111 Lv10*
*Code : 1010013 Lv9*
*Code : 7010077 Lv9*
*Code : 3188000 Lv8*
⊦──────────────────────▻
_*WEAPON ATK*_
*Code : 1010099 Lv10*
*Code : 1010810 Lv10*
*Code : 1011126 Lv10*
*Code : 6010024 Lv10*
*Code : 2020404 Lv10*
*Code : 2010136 Lv10*
*Code : 1010029 Lv10*
*Code : 7010032 Lv10*
*Code : 7010023 Lv10*
*Code : 7086969 Lv10*
*Code : 1067777 Lv10*
*Code : 6100000 Lv10*
*Code : 2010007 Lv10*
*Code : 3132109 Lv10*
*Code : 1010029 Lv10*
*Code : 3070028 Lv9*
*Code : 7162029 Lv9*
*Code : 2221806 Lv9*
⊦──────────────────────▻
_*AMPR*_
*Code : 1023040 Lv10*
*Code : 1010017 Lv10*
*Code : 1010092 Lv10*
*Code : 1010006 Lv10*
*Code : 5240001 Lv10*
*Code : 1010050 Lv10*
*Code : 1019696 Lv10*
*Code : 3226325 Lv10*
*Code : 5010103 Lv10*
*Code : 1011010 Lv10*
*Code : 3063101 Lv10*
*Code : 3062728 Lv10*
*Code : 1010006 Lv10*
*Code : 4040404 Lv10*
*Code : 3062111 Lv10*
*Code : 5252525 Lv10*
*Code : 2010068 Lv10*
*Code : 4206969 Lv10*
*Code : 5010031 Lv10*
*Code : 1010001 Lv9*
*Code : 1030002 Lv9*
*Code : 1023040 Lv9*
*Code : 5240202 Lv9*
*Code : 1234321 Lv9*
*Code : 1010058 Lv8*
*Code : 2011111 Lv8*
⊦──────────────────────▻
_*HP*_
*Code : 3011143 Lv10*
*Code : 1180755 Lv10*
*Code : 1010032 Lv10*
*Code : 1010084 Lv10*
*Code : 1010101 Lv10*
*Code : 1011945 Lv10*
*Code : 1222002 Lv10*
*Code : 1234567 Lv10*
*Code : 3011143 Lv10*
*Code : 1010203 Lv10*
*Code : 6010062 Lv10*
*Code : 3191130 Lv10*
*Code : 1010084 Lv10*
*Code : 3010058 Lv10*
*Code : 3010006 Lv10*
*Code : 3066969 Lv10*
*Code : 1222002 Lv10*
*Code : 7121252 Lv9*
*Code : 3011143 Lv9*
*Code : 3015555 Lv9*
*Code : Sofya - A - 420 Lv9*
*Code : 1260303 Lv7*
*Code : 1250555 Lv5*
⊦──────────────────────▻
_*MP*_
*Code : 1010216 Lv10*
*Code : 3080021 Lv10*
*Code : 6010021 Lv10*
*Code : 6052000 Lv10*
*Code : 7010047 Lv10*
*Code : 6070013 Lv10*
*Code : 3204544 Lv10*
*Code : 1016646 Lv10*
*Code : 4011793 Lv10*
*Code : 1010013 Lv10*
*Code : 1011212 Lv10*
*Code : 3080021 Lv10*
*Code : 1111999 Lv10*
*Code : 1027777 Lv10*
*Code : 3113105 Lv10*
*Code : 3010037 Lv10*
*Code : 3010069 Lv10*
*Code : 1100008 Lv10*
*Code : 2010079 Lv10*
*Code : 5010080 Lv10*
*Code : 2010091 Lv10*
*Code : 1010142 Lv10*
*Code : 6070013 Lv10*
*Code : 1042374 Lv9*
*Code : 1010004 Lv9*
*Code : 4046666 Lv8*
*Code : 1059999 Lv8*
*Code : 1010017 Lv6*
⊦──────────────────────▻
_*- AGGRO*_
*Code : 1010038 Lv10*
*Code : 1010002 Lv10*
*Code : 1010147 Lv10*
*Code : 1016646 Lv10*
*Code : 6010009 Lv10*
*Code : 3010018 Lv10*
*Code : Sofya - A - 2 Lv10*
*Code : 6010009 Lv9*
*Code : 2020808 Lv9*
*Code : 3134610 Lv9*
*Code : 1261807 Lv9*
*Code : 7190001 Lv9*
*Code : 3061206 Lv8*
*Code : 5092107 Lv8*
*Code : 4200963 Lv8*
⊦──────────────────────▻
_*+ AGGRO*_
*Code : 2020606 Lv10*
*Code : 3030110 Lv10*
*Code : 1264321 Lv10*
*Code : 3053131 Lv10*
*Code : 1016646 Lv10*
*Code : 6262000 Lv10*
*Code : 1010207 Lv10*
*Code : 3204544 Lv10*
*Code : 3158668 Lv10*
*Code : 6262000 Lv9*
*Code : 1190069 Lv9*
*Code : 1013000 Lv9*
*Code : 7261597 Lv9*
*Code : 3066969 Lv9*
*Code : 1014230 Lv9*
*Code : 2020606 Lv9*
*Code : 2010136 Lv9*
*Code : 1013000 Lv9*
*Code : 3030110 Lv7*
*Code : 1012000 Lv7*
⊦──────────────────────▻
_*PHYSICAL RESIST*_
*Code : 1020001 Lv10*
*Code : 1100000 Lv10*
*Code : 3010034 Lv10*
*Code : 7010014 Lv10*
*Code : 1018989 Lv9*
*Code : 1100000 Lv9*
*Code : 6011415 Lv9*
*Code : 4200069 Lv9*
*Code : 6010701 Lv9*
*Code : 3011999 Lv9*
*Code : 1018989 Lv8*
⊦──────────────────────▻
_*MAGICAL RESIST*_
*Code : 1010004 Lv10*
*Code : 2020505 Lv10*
*Code : 5246969 Lv10*
*Code : 7010016 Lv10*
*Code : 7030023 Lv10*
*Code : 4080087 Lv9*
*Code : 1100000 Lv9*
*Code : 7227777 Lv9*
*Code : 7222227 Lv9*
*Code : 4010417 Lv7*
⊦──────────────────────▻
_*FRACTIONAL BARRIER*_
*Code : 7010082 Lv10*
*Code : 1222002 Lv8*
*Code : 6181999 Lv8*
*Code : 6010062 Lv8*
⊦──────────────────────▻
_*DTE WATER*_
*Code : 7150030 Lv9*
*Code : 3210100 Lv9*
*Code : 7011001 Lv8*
*Code : 3062111 Lv8*
*Code : 3030777 Lv8*
*Code : 2260006 Lv8*
*Code : 1110111 Lv8*
*Code : 1110007 Lv7*
*Code : 6070013 Lv7*
*Code : 1010067 Lv7*
*Code : 3226325 Lv7*
*Code : 3010018 Lv7*
*Code : 2173179 Lv6*
*Code : 3226325 Lv6*
*Code : 1110007 Lv4*
⊦──────────────────────▻
_*DTE FIRE*_
*Code : 3210106 Lv9*
*Code : 7011001 Lv8*
*Code : 1010799 Lv7*
*Code : 1012610 Lv7*
*Code : 2010091 Lv6*
*Code : 1012610 Lv5*
*Code : 4084545 Lv5*
*Code : 1010101 Lv4*
⊦──────────────────────▻
_*DTE EARTH*_
*Code : 3210103 Lv9*
*Code : 1011001 Lv9*
*Code : 2020202 Lv9*
*Code : 1011111 Lv8*
*Code : 2022222 Lv8*
*Code : 4083005 Lv8*
*Code : 1016646 Lv8*
*Code : 4046666 Lv8*
*Code : 1010002 Lv8*
*Code : 6010003 Lv8*
*Code : 2099876 Lv7*
*Code : 1010174 Lv7*
*Code : 5240001 Lv7*
*Code : 3011143 Lv7*
*Code : 1016646 Lv7*
*Code : 1010142 Lv7*
*Code : 1011111 Lv7*
*Code : 1010002 Lv6*
*Code : 7121252 Lv6*
*Code : 7010005 Lv6*
*Code : 6010024 Lv6*
⊦──────────────────────▻
_*DTE WIND*_
*Code : 3210101 Lv9*
*Code : 3030303 Lv8*
*Code : 3062111 Lv8*
*Code : 1010055 Lv7*
*Code : 4099876 Lv7*
*Code : 7190001 Lv7*
*Code : 7190001 Lv4*
⊦──────────────────────▻
_*DTE LIGHT*_
*Code : 3210105 Lv9*
*Code : 1020345 Lv9*
*Code : 3210106 Lv9*
*Code : 4046666 Lv8*
*Code : 1020345 Lv8*
*Code : Rugio - Z - 6 Lv8*
*Code : 7031000 Lv6*
*Code : 4016699 Lv6*
*Code : 7077777 Lv6*
⊦──────────────────────▻
_*DTE DARK*_
*Code : 1190020 Lv10*
*Code : 3210104 Lv9*
*Code : 5010092 Lv9*
*Code : 1010006 Lv9*
*Code : 1010006 Lv8*
*Code : 6010003 Lv8*
*Code : 1016646 Lv8*
*Code : 7010023 Lv8*
*Code : 1010006 Lv7*
*Code : 1016646 Lv7*
*Code : 1091111 Lv7*
*Code : 3030069 Lv7*
*Code : 3030324 Lv7*
*Code : 1190072 Lv7*
⊦──────────────────────▻
_*DTE NETRAL*_
*Code : 3210102 Lv9*
*Code : 2010071 Lv9*
*Code : 1019696 Lv9*
*Code : 1016969 Lv9*
*Code : 3010095 Lv8*
*Code : 3099876 Lv7*
*Code : 1011902 Lv7*
*Code : 6061294 Lv7*
*Code : 1019696 Lv6*
*Code : 6061294 Lv6*
*Code : 4206969 Lv6*
*Code : 1032727 Lv5*
⊦──────────────────────▻
_*DROP RATE*_
*Code : 4196969 Lv6*
*Code : 1010085 Lv6*
*Code : 1010018 Lv5*
╭──────────────────────▻
╰─────[`, m) 
} 
handler.menutoram = ['bufflist toram'] 
handler.tagstoram = ['toram'] 
handler.command = /^(buff|bufflist)$/i 
export default handler