let handler = () => {
    console.log('Bot telah On')
}

handler()